import React, { useEffect } from 'react';
import AppLoading from 'expo-app-loading';
import { Routes }  from './src/routes';

export default function App(){

  return (
    <Routes />
  )
}
